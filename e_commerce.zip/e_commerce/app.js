
const express = require('express');
const app = express();

// Additional configurations and middleware can go here

module.exports = app;
