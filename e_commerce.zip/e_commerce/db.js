
const mysql = require('mysql');

// Create a connection to the database
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '28122002Zain@',
    database: 'e_commerce'
});

// Connect to the database
db.connect(err => {
    if (err) {
        console.error('Error connecting to the database:', err);
        process.exit(1); // Exit process if unable to connect
    }
    console.log('MySQL connected...');
});

module.exports = db;
